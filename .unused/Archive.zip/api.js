const { render, setText } = require("./app")

export function request(method = 'POST', path = '', args = {}, body = null) {
	return new Promise((resolve, reject) => {
		const req = new XMLHttpRequest
		const params = Object.entries(args)
		const uri = path + (params.length ? '?' + params.map(([key, value]) => `${key}=${value}`).join('&') : '')
		const size = body ? ` [${body.size || body.length} Kb]` : ''
		const output = console.log(`${method} ${uri} ${size}... `)

		req.open(method, uri, true)
		req.send(body)
		req.addEventListener('load', () => {
			if (output) {
				// output.innerHTML += `[${req.status} ${req.statusText}] ${req.responseText.split("\n")[0]}`
				output.innerHTML += req.statusText
			}
			if (req.status === 200) {
				if (req.getResponseHeader('Content-Type') === 'application/json') {
					resolve(JSON.parse(req.responseText), req)
				} else resolve(req.responseText, req)
			} else {
				reject()
			}
		})
		req.addEventListener('error', reject)
	})
}

export function uploadFile(path, file, sync = false, target = null) {
	if (typeof file === 'string') file = new Blob([file])
	const output = console.log(`UPLOAD ${path} [${(file.size / 1000).toFixed(2)} KB] ... `)
	return new Promise((resolve, reject) => {
		const form = new FormData()
		const req = new XMLHttpRequest()
		form.append('filename', path)
		form.append('file', file)
		req.open('POST', `edit?${sync ? 'sync' : 'nosync'}&${target ? `target=${target}` : ''}`, true)
		req.send(form)
		req.onloadend = (e) => {
			if (output) {
				output.innerHTML += req.statusText
			}
			if (req.status === 200) {
				resolve(req)
			} else {
				reject(req)
			}
		}
	})
}

export function get(path, params) {
	return request('GET', path, params)
}
export function post(path, params, body) {
	return request('POST', path, params, body)
}
export function sendCommand(cmd) {
	// console.log('execute ' + cmd)
	return request('POST', 'exec', { cmd })
}

export function loadAudioConfig() {
	return get(`show/${CONFIG.show}.json`).then(res => {
		Object.assign(AUDIO, res)
		renderAudio()
	})
}
export async function loadShowData() {
	// const A = await get(`show/${CONFIG.show}A.lsb`)
	// const B = await get(`show/${CONFIG.show}B.lsb`)
	const files = await get(`list?dir=/show`)
	console.log(files)
}
export async function fetchData() {
	const result = await get('stat')
	Object.assign(CONFIG, result)
	if (result.show) await loadShowData();
	render()
}
export function stopShow() {
	return sendCommand('end').then(() => {
		call('#player', 'pause')
		setProp('#player', 'currentTime', 0)
	})
}
export function startShow() {
	return sendCommand('start').then(() => {
		setProp('#player', 'currentTime', 0)
		return call('#player', 'play')
	})
}
export function resetShow() {
	console.log(`reset show #${CONFIG.show}`);
	AUDIO = Object.assign({}, AUDIO_DEFAULT)
	AUDIO.id = CONFIG.show
	SHOWS.length = 0
	render()
	return stopShow()
		.then(clearLightShow)
}
export function saveShow() {
	return stopShow()
		.then(saveAudioConfig)
		.then(saveLightShow)
		.then(startShow)
}

Object.assign(window, {
	request,
	uploadFile,
	get,
	post,
	sendCommand,
	loadAudioConfig,
	loadShowData,
	fetchData,
	stopShow,
	startShow,
	resetShow,
	saveShow
})
