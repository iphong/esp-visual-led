
function $(selector) {
	return document.body.querySelectorAll(selector)
}
function setText(selector, text) {
	if (typeof text === 'undefined') return
	$(selector).forEach(el => {
		el.innerHTML = text
	})
}
function setValue(selector, value) {
	if (typeof value === 'undefined') return
	$(selector).forEach(el => {
		el.value = value
	})
}
function setProp(selector, prop, value) {
	if (typeof value === 'undefined') return
	$(selector).forEach(el => {
		el[prop] = value
	})
}
function setAttr(selector, attr, value) {
	if (typeof value === 'undefined') return
	$(selector).forEach(el => {
		el.setAttribute(attr, value)
	})
}
function click(selector) {
	$(selector).forEach(el => {
		el.click()
	})
}
function call(selector, method, ...args) {
	$(selector).forEach(el => {
		if (typeof el[method] === 'function') {
			el[method].call(el, ...args)
		}
	})
}

// render rgb and hsl color input sliders
function renderColor() {
	Object.keys(color).forEach(group => {
		Object.keys(color[group]).forEach(channel => {
			const el = document.querySelector(`input[data-group="${group}"][data-key="${channel}"]`)
			if (el) {
				el.value = color[group][channel]
				const span = el.parentElement.querySelector('span')
				if (span) {
					switch (group) {
						case 'hsl':
							span.innerText = Math.round(color[group][channel] * 100) + '%'
							break
						case 'rgb':
							span.innerText = el.value
					}
				}
			}
		})
	})
}

function renderHead() {
	const { id, ip, mac, brightness, channel, show } = CONFIG
	setText('#id', id)
	setText('#ip', ip)
	setText('#mac', mac)
}

// render ui components bound to current show
function renderShow() {
	$('[data-show]').forEach(el => {
		if (parseInt(el.dataset.show) === CONFIG.show) {
			el.classList.add('selected')
		} else {
			el.classList.remove('selected')
		}
	})
	$('[data-segment]').forEach(el => {
		if (el.dataset.segment === CONFIG.segment) {
			el.classList.add('selected')
		} else {
			el.classList.remove('selected')
		}
	})
}
function renderShowTimeline(selector, content) {
	$(selector).forEach(wrapper => {
		wrapper.innerHTML = ''
		let lastColor = `rgb(0,0,0)`
		content.split('\n').forEach(line => {
			if (line.trim().startsWith('C')) {
				const [, start, duration, transition, r, g, b] = line.trim().split(' ')
				const color = `rgb(${r},${g},${b})`
				const percent = Math.round(transition / duration * 100)

				const frame = document.createElement('span')
				frame.classList.add('frame')
				frame.style.width = `${Math.round(parseInt(duration) / 10)}px`
				frame.style.background = `linear-gradient(90deg, ${lastColor}0px, ${color} ${Math.round(transition / 10)}px, ${color} ${Math.round(duration / 10)}px)`
				wrapper.appendChild(frame)
				lastColor = color
			}
		})
	})
}
function renderAudio() {
	setAttr('#player', 'src', AUDIO.url)
	setText('#audio-filename', AUDIO.filename)
	setText('#audio-duration', Math.round(AUDIO.duration))
	setText('#audio-tempo', AUDIO.tempo)
	setText('#audio-beats', AUDIO.beats)
	setValue('#audio-color1', AUDIO.color1)
	setValue('#audio-color2', AUDIO.color2)
	setValue('#audio-ratio', AUDIO.ratio)
}

function render() {
	renderHead()
	renderShow()
	// renderColor()
	// renderAudio()
}

Object.assign(window, {
	$,
	setText,
	setValue,
	setProp,
	setAttr,
	click,
	call,
	renderColor,
	renderShow,
	renderShowTimeline,
	renderAudio,
	render
})
export {
	$,
	setText,
	setValue,
	setProp,
	setAttr,
	click,
	call,
	renderColor,
	renderShow,
	renderShowTimeline,
	renderAudio,
	render
}
